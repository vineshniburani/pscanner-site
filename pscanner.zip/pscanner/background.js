const KEY = "ember";
const MAX_PER_TAB = 150;
const HOSTS = ["paruluniversity.ac.in", "digitaloceanspaces.com", "edorer.com"];
const PATTERNS = [
  "https://elearning.paruluniversity.ac.in/*",
  "https://*.paruluniversity.ac.in/*",
  "https://*.digitaloceanspaces.com/*",
  "https://*.edorer.com/*"
];
const MIME_EXT = {
  "application/pdf": "pdf",
  "application/vnd.ms-powerpoint": "ppt",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx"
};
const EXT_RE = /\.(pdf|pptx?)$/i;

const allowedUrl = raw => {
  try {
    const u = new URL(raw);
    return u.protocol === "https:" && HOSTS.some(h => u.hostname === h || u.hostname.endsWith("." + h));
  } catch { return false; }
};
const header = (headers, name) =>
  (headers || []).find(h => h.name.toLowerCase() === name)?.value || "";

function filenameFromDisposition(v) {
  if (!v) return "";
  const star = v.match(/filename\*\s*=\s*UTF-8''([^;]+)/i);
  if (star) { try { return decodeURIComponent(star[1].trim().replace(/^"|"$/g, "")); } catch {} }
  const basic = v.match(/filename\s*=\s*(?:"([^"]+)"|([^;]+))/i);
  return basic ? (basic[1] || basic[2] || "").trim() : "";
}
const safeName = (v, fb = "course-material") =>
  ((v || fb).replace(/[\\/:*?"<>|\u0000-\u001F]/g, "_").trim() || fb).slice(0, 160);

/* ---------- state: in-memory cache + serialized writes (no race conditions) ---------- */
let cache = null, queue = Promise.resolve();
const load = async () => cache ??= (await chrome.storage.session.get(KEY))[KEY] || {};
const mutate = fn => (queue = queue.then(async () => {
  const s = await load();
  const out = await fn(s);
  await chrome.storage.session.set({ [KEY]: s });
  return out;
}).catch(() => {}));

function badge(tabId, n) {
  chrome.action.setBadgeText({ tabId, text: n ? String(n) : "" }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#FF6A00" }).catch(() => {});
  try { chrome.action.setBadgeTextColor({ tabId, color: "#000000" }); } catch {}
}

function makeItem(url, filename = "", contentType = "", size = 0) {
  if (!allowedUrl(url)) return null;
  const urlExt = (url.match(/\.(pdf|pptx?)(?:$|[?#])/i) || [])[1];
  const mimeExt = MIME_EXT[contentType.split(";")[0].trim().toLowerCase()];
  if (!urlExt && !EXT_RE.test(filename) && !mimeExt) return null;
  let name = filename;
  if (!name) { try { name = decodeURIComponent(new URL(url).pathname.split("/").pop() || ""); } catch {} }
  if (!EXT_RE.test(name)) name = `${name || "course-material"}.${(urlExt || mimeExt || "pdf").toLowerCase()}`;
  name = safeName(name);
  const u = new URL(url);
  return {
    id: crypto.randomUUID(),
    key: u.pathname,                        // ignore host + signed query; same file may come via two hosts
    url, name, size,
    type: (name.match(EXT_RE)?.[1] || "FILE").toUpperCase(),
    contentType, title: ""
  };
}

function saveItem(tabId, item) {
  if (tabId < 0 || !item) return;
  return mutate(s => {
    const list = s[tabId] || [];
    const i = list.findIndex(x => x.key === item.key);
    if (i >= 0) { item.id = list[i].id; item.title = list[i].title || item.title; list.splice(i, 1); }   // refresh expired signed link
    list.unshift({ ...item, tabId, seenAt: Date.now() });
    s[tabId] = list.slice(0, MAX_PER_TAB);
    badge(tabId, s[tabId].length);
  });
}

/* ---------- network capture (only on granted hosts) ---------- */
function onHeaders(d) {
  if (d.tabId < 0) return;
  const h = d.responseHeaders;
  const item = makeItem(
    d.url,
    filenameFromDisposition(header(h, "content-disposition")),
    header(h, "content-type"),
    Number(header(h, "content-length")) || 0
  );
  if (item) saveItem(d.tabId, item)?.then(() => tagTitle(d.tabId, item.key));
}
function listen() {
  try {
    chrome.webRequest.onHeadersReceived.removeListener(onHeaders);
    chrome.webRequest.onHeadersReceived.addListener(
      onHeaders,
      { urls: PATTERNS, types: ["xmlhttprequest", "other", "object", "sub_frame", "main_frame"] },
      ["responseHeaders"]
    );
  } catch {}
}
listen();
chrome.permissions.onAdded.addListener(listen);

/* ---------- naming: each file keeps the title it was opened under ---------- */
const GENERATED = /^[0-9a-f]{8}-[0-9a-f]{4}-/i;
const UUID_PREFIX = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}-?/i;
function withTitle(item) {
  const ext = (item.name.match(EXT_RE) || [".pdf"])[0].toLowerCase();
  const t = (item.title || "").replace(/\.(pdf|pptx?)$/i, "").trim();
  if (t && GENERATED.test(item.name)) return { ...item, name: safeName(t) + ext };
  const clean = item.name.replace(UUID_PREFIX, "").replace(/-+(?=\.[a-z0-9]+$)/i, "");
  return EXT_RE.test(clean) && clean.length > 4 ? { ...item, name: clean } : item;
}
// Same title = same file loaded twice (two hosts). Different titles are always kept.
function dedupe(list) {
  const out = new Map();
  for (const raw of list) {
    const it = withTitle(raw), k = raw.title ? "t:" + raw.title.toLowerCase() : "k:" + raw.key, prev = out.get(k);
    if (!prev || (!prev.size && it.size)) out.set(k, it);
  }
  return [...out.values()];
}
// Ask the portal tab what title it shows shortly after a file loads, and pin it to that file.
async function tagTitle(tabId, key) {
  for (let i = 0; i < 5; i++) {
    await new Promise(r => setTimeout(r, 900));
    let t = "";
    try { t = (await chrome.tabs.sendMessage(tabId, { type: "GET_TITLE" }))?.title || ""; } catch { return; }
    if (t) { await mutate(s => { const it = (s[tabId] || []).find(x => x.key === key); if (it && !it.title) it.title = t; }); return; }
  }
  // No viewer title on screen: the portal fetched this in the background (prefetch/list), the user didn't open it. Drop it.
  await mutate(s => {
    const l = s[tabId] || [], i = l.findIndex(x => x.key === key && !x.title);
    if (i >= 0) { l.splice(i, 1); badge(tabId, l.length); }
  });
}
// Popup fallback: give the newest untitled batch the title currently on screen.
function assignTitle(tabId, title) {
  return mutate(s => {
    const un = (s[tabId] || []).filter(x => !x.title);
    if (!un.length) return;
    const newest = Math.max(...un.map(x => x.seenAt));
    for (const x of un) if (x.seenAt >= newest - 5000) x.title = title;
  });
}

/* ---------- messaging ---------- */
async function download(item, saveAs) {
  if (!item || !allowedUrl(item.url)) return { ok: false, error: "That file is outside the allowed portal domains." };
  try {
    const downloadId = await chrome.downloads.download({
      url: item.url, filename: safeName(item.name), conflictAction: "uniquify", saveAs
    });
    return { ok: true, downloadId };
  } catch (e) {
    return { ok: false, error: e?.message || "Chrome could not start the download. Reopen the material and try again." };
  }
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    switch (m?.type) {
      case "CAPTURE_URL": {
        const item = makeItem(m.url, m.name || "", m.contentType || "");
        if (sender.tab?.id != null && item) { await saveItem(sender.tab.id, item); tagTitle(sender.tab.id, item.key); }
        return { ok: !!item };
      }
      case "GET_ITEMS":
        if (m.title) await assignTitle(m.tabId, m.title);
        return { items: dedupe((await load())[m.tabId] || []) };
      case "CLEAR_ITEMS":
        await mutate(s => { delete s[m.tabId]; });
        badge(m.tabId, 0);
        return { ok: true };
      case "DOWNLOAD": {
        const item = ((await load())[m.tabId] || []).find(x => x.id === m.id);
        return download(item && withTitle(item), false);
      }
      case "DOWNLOAD_ALL": {
        const list = dedupe((await load())[m.tabId] || []);
        const results = await Promise.all(list.map(i => download(i, false)));
        return { ok: true, started: results.filter(r => r.ok).length, total: list.length };
      }
    }
    return { ok: false };
  })().then(reply).catch(e => reply({ ok: false, error: e?.message || "Unexpected error" }));
  return true;
});

chrome.tabs.onRemoved.addListener(tabId => mutate(s => { delete s[tabId]; }));

// Icon click: toggle the floating panel. If the page script isn't there yet
// (tab opened before install/update), inject it first so no reload is needed.
// Icon click: show the floating rounded panel on any page (injecting the page script on demand).
// Only if a page can't host it (restricted page, strict site rules) do we fall back to Chrome's own popup.
const nativeFallback = tabId =>
  chrome.action.setPopup({ tabId, popup: "popup.html" }).then(() => chrome.action.openPopup()).catch(() => {});
async function togglePanel(tab) {
  const msg = { type: "TOGGLE_PANEL", tabId: tab.id };
  try { await chrome.tabs.sendMessage(tab.id, msg); return; } catch {}
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch { nativeFallback(tab.id); }
}
chrome.action.onClicked.addListener(togglePanel);
chrome.runtime.onMessage.addListener((m, sender) => {
  if (m?.type === "PANEL_FAILED" && sender.tab?.id != null) nativeFallback(sender.tab.id);
});
