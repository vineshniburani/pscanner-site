(() => {
  // Avoid double-loading when injected on demand; an orphaned copy from a reloaded extension reports dead.
  if (window.__psAlive?.()) return;
  window.__psAlive = () => { try { return !!chrome.runtime.id; } catch { return false; } };
  const EXT = /\.(pdf|pptx?)(?:$|[?#])/i;
  const HOSTS = ["paruluniversity.ac.in", "digitaloceanspaces.com", "edorer.com"];
  const SEL = "iframe[src],embed[src],object[data],[pdf-src],[src-url],ngx-extended-pdf-viewer,pdf-viewer";
  const ATTRS = ["href", "src", "data", "src-url", "pdf-src", "url"];
  const seen = new Set();
  let pending = false;

  const idle = cb => "requestIdleCallback" in window ? requestIdleCallback(cb, { timeout: 800 }) : setTimeout(cb, 200);

  function report(raw, name = "") {
    if (!raw || raw.startsWith("blob:") || raw.startsWith("data:")) return;
    let u;
    try { u = new URL(raw, location.href); } catch { return; }
    if (u.protocol !== "https:" || seen.has(u.href)) return;
    if (!HOSTS.some(h => u.hostname === h || u.hostname.endsWith("." + h))) return;
    if (!EXT.test(u.href) && !EXT.test(name)) return;
    seen.add(u.href);
    chrome.runtime.sendMessage({ type: "CAPTURE_URL", url: u.href, name }).catch(() => {});
  }

  function scan() {
    pending = false;
    for (const el of document.querySelectorAll(SEL)) {
      let raw = "";
      for (const a of ATTRS) if ((raw = el.getAttribute(a))) break;
      report(raw, el.getAttribute("download") || el.getAttribute("title") || "");
    }
  }
  const schedule = () => { if (!pending) { pending = true; idle(scan); } };

  const TAG = /^(pdf|ppt|pptx|doc|docx|file)$/i;
  function pageTitle() {
    const back = [...document.querySelectorAll("button,a,[role=button]")]
      .find(e => /^\W*back\W*$/i.test(e.textContent.trim()));
    let n = back;
    for (let hop = 0; n && hop < 4; hop++, n = n.parentElement) {
      for (let s = n.nextElementSibling; s; s = s.nextElementSibling) {
        const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
        for (let t; (t = w.nextNode());) {
          const txt = t.textContent.trim();
          if (txt && !TAG.test(txt)) return txt;
        }
      }
    }
    return "";
  }
  let frame = null, ready = false, readyTimer = 0;
  const EXT_ORIGIN = new URL(chrome.runtime.getURL("")).origin;
  function closePanel() { clearTimeout(readyTimer); frame?.remove(); frame = null; ready = false; }
  function openPanel(tabId) {
    frame = document.createElement("iframe");
    frame.src = chrome.runtime.getURL("popup.html") + "?tab=" + tabId;
    frame.style.cssText = "position:fixed;top:14px;right:18px;width:390px;height:420px;border:0;" +
      "border-radius:30px;z-index:2147483647;background:transparent;overflow:hidden;" +
      "box-shadow:0 26px 60px -14px rgba(0,0,0,.6);";
    document.documentElement.appendChild(frame);
    // If the page's security rules block the panel, it never reports ready: close it and use Chrome's popup instead.
    readyTimer = setTimeout(() => { if (frame && !ready) { closePanel(); chrome.runtime.sendMessage({ type: "PANEL_FAILED" }).catch(() => {}); } }, 2200);
  }
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m?.type === "GET_TITLE") reply({ title: pageTitle() });
    if (m?.type === "TOGGLE_PANEL") { frame ? closePanel() : openPanel(m.tabId); reply({ ok: true }); }
  });
  addEventListener("message", e => {
    if (!frame || e.origin !== EXT_ORIGIN) return;
    if (e.data?.ps === "ready") ready = true;
    if (e.data?.ps === "size") frame.style.height = Math.min(e.data.h, innerHeight - 28) + "px";
    if (e.data?.ps === "close") closePanel();
  });
  document.addEventListener("pointerdown", () => closePanel(), true);
  document.addEventListener("keydown", e => { if (e.key === "Escape") closePanel(); });

  scan();
  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true, subtree: true, attributes: true, attributeFilter: ATTRS
  });
  // Resource timing replaces the old 2.5s polling loop: it fires only when something loads.
  try {
    new PerformanceObserver(list => list.getEntries().forEach(e => report(e.name)))
      .observe({ type: "resource", buffered: true });
  } catch {}
})();
