# PScanner

Chrome (Manifest V3) extension that finds PDF/PPT/PPTX files on the Parul University e-learning portal and downloads them in one click.

## Install
1. Unzip, open `chrome://extensions`, enable Developer mode.
2. Load unpacked, pick the `ember` folder (the one with `manifest.json`).
3. Sign in to the portal, click PScanner, press Allow on this site.
4. Open the material, reload if needed, press Refresh, then Download or Download all.

## What's new in 2.0
- Rounded portfolio-style UI with dark/light theme toggle, bundled Poppins font, tilting cards.
- Orange badge on the toolbar icon shows how many files each tab has.
- Download all button; file sizes shown when the server reports them.
- Network listener now runs only on the portal hosts (before: every https site).
- No more 2.5s polling; page scanning is debounced and uses PerformanceObserver.
- Serialized, cached storage writes (no lost items); refreshed signed links replace expired ones instead of duplicating.

It does not bypass logins, DRM or access controls.


Designed by Vinesh Niburani.
