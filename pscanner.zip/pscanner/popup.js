const $ = id => document.getElementById(id);
const ORIGINS = [
  "https://elearning.paruluniversity.ac.in/*", "https://*.paruluniversity.ac.in/*",
  "https://*.digitaloceanspaces.com/*", "https://*.edorer.com/*"
];
let tabId = null, title = "";
// Runs inside the portal tab; reads the title shown next to the Back button.
function pageTitleInTab() {
  const TAG = /^(pdf|ppt|pptx|doc|docx|file)$/i;
  const back = [...document.querySelectorAll("button,a,[role=button]")]
    .find(e => /^\W*back\W*$/i.test(e.textContent.trim()));
  let n = back;
  for (let hop = 0; n && hop < 4; hop++, n = n.parentElement) {
    for (let s = n.nextElementSibling; s; s = s.nextElementSibling) {
      const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT);
      for (let t; (t = w.nextNode());) {
        const txt = t.textContent.trim();
        if (txt && !TAG.test(txt)) return txt;
      }
    }
  }
  return "";
}
const readTitle = async () => {
  title = "";
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: pageTitleInTab });
    title = r?.result || "";
  } catch {}
};
const send = msg => chrome.runtime.sendMessage(msg);
const say = (t, err = false) => { $("status").textContent = t; $("status").classList.toggle("err", err); };
const fmtSize = b => !b ? "" : b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`;

async function checkPermission() {
  const has = await chrome.permissions.contains({ origins: ORIGINS });
  $("permission").classList.toggle("hidden", has);
  return has;
}

function tilt(li) {
  li.addEventListener("pointermove", e => {
    const r = li.getBoundingClientRect();
    li.style.setProperty("--ry", `${((e.clientX - r.left) / r.width - .5) * 7}deg`);
    li.style.setProperty("--rx", `${-((e.clientY - r.top) / r.height - .5) * 7}deg`);
  });
  li.addEventListener("pointerleave", () => { li.style.removeProperty("--rx"); li.style.removeProperty("--ry"); });
}

function card(item, i) {
  const li = document.createElement("li");
  li.style.setProperty("--i", Math.min(i, 8));
  const row = Object.assign(document.createElement("div"), { className: "row" });
  const badge = Object.assign(document.createElement("div"), {
    className: "badge" + (item.type.startsWith("PPT") ? " ppt" : ""), textContent: item.type });
  const info = Object.assign(document.createElement("div"), { className: "info" });
  const name = Object.assign(document.createElement("div"), { className: "name", textContent: item.name, title: item.name });
  const meta = Object.assign(document.createElement("div"), { className: "meta",
    textContent: [fmtSize(item.size), new Date(item.seenAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })].filter(Boolean).join("  ") });
  const btn = Object.assign(document.createElement("button"), { className: "primary", textContent: "Download" });
  btn.addEventListener("click", async () => {
    btn.disabled = true; btn.textContent = "Starting…";
    const r = await send({ type: "DOWNLOAD", tabId, id: item.id, title });
    if (r?.ok) { btn.textContent = "Saved"; }
    else { btn.disabled = false; btn.textContent = "Retry"; say(r?.error || "Download failed. Reopen the material and retry.", true); }
  });
  info.append(name, meta); row.append(badge, info, btn); li.append(row); tilt(li);
  return li;
}

async function load() {
  if (tabId == null) return;
  await readTitle();
  const { items = [] } = (await send({ type: "GET_ITEMS", tabId, title })) || {};
  $("count").textContent = items.length;
  $("all").disabled = !items.length;
  $("items").replaceChildren(...items.map(card));
  say(items.length ? "Pick a file, or download everything at once."
    : "Nothing yet. Open the material in this tab, wait a moment, then press Refresh.");
}

async function init() {
  const forced = Number(new URLSearchParams(location.search).get("tab"));
  const tab = forced ? await chrome.tabs.get(forced) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (tab?.url && !/^https:\/\/elearning\.paruluniversity\.ac\.in\//.test(tab.url)) {
    document.body.classList.add("offsite");
    $("offsite").classList.remove("hidden");
    try { $("site").textContent = new URL(tab.url).host || "This page"; } catch { $("site").textContent = "This page"; }
    return;
  }
  if (!tab?.id || !/^https?:/i.test(tab.url || "")) {
    $("site").textContent = "Not a website tab";
    say("Open your Parul e-learning tab, then click Ember again.", true);
    $("refresh").disabled = $("clear").disabled = true;
    return;
  }
  tabId = tab.id;
  $("site").textContent = new URL(tab.url).host;
  await checkPermission();
  await load();
}

$("grant").onclick = async () => {
  if (await chrome.permissions.request({ origins: ORIGINS })) {
    await checkPermission();
    say("Ember is on. Reload the course page so it can see the files.");
  }
};
$("refresh").onclick = load;
$("clear").onclick = async () => { await send({ type: "CLEAR_ITEMS", tabId }); load(); };
$("all").onclick = async () => {
  $("all").disabled = true;
  const r = await send({ type: "DOWNLOAD_ALL", tabId, title });
  say(`Started ${r?.started ?? 0} of ${r?.total ?? 0} downloads.`);
  $("all").disabled = false;
};
init().catch(e => say(e?.message || "Ember could not start.", true));

$("theme").onclick = () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("ps-theme", next);
};

// Floating-panel plumbing: tell the page how tall we are, close on Esc.
const framed = window.top !== window;
if (!framed) document.documentElement.classList.add("solid");
const app = document.querySelector(".app");
const postSize = () => framed && parent.postMessage({ ps: "size", h: app.offsetHeight }, "*");
new ResizeObserver(postSize).observe(app);
addEventListener("keydown", e => { if (e.key === "Escape" && framed) parent.postMessage({ ps: "close" }, "*"); });

$("openPortal").onclick = () => chrome.tabs.create({ url: "https://elearning.paruluniversity.ac.in/" });
if (framed) parent.postMessage({ ps: "ready" }, "*");
