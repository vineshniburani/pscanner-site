document.documentElement.dataset.theme = localStorage.getItem("ps-theme") || "dark";
